File Structure

|_public
  |_css
  |_html
  |_js
|_views
  |_layouts
  |_partials
|_database
 
